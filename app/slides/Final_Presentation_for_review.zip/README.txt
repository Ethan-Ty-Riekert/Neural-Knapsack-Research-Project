Final presentation - review pack
Ethan Ty Riekert, Curtin University. Supervisors: Elham Mardaneh, Tony Mathew.

Contents
  Final_Presentation.pptx   the 4-slide deck (speaker notes are included)
  training_demo.html        "How Reinforcement Learning Works": the interactive training demo (slide 2 button)
  scheduler_race.html       the Scheduler Race page (slide 3 button)

How to use
  1. Extract ALL files into the same folder (the buttons on slides 2 and 3 open the two .html files by name,
     so they only work when the three files sit together and the zip is extracted first).
  2. Open the .pptx in PowerPoint and click the buttons in slideshow mode, or double-click the .html files
     to open them in any browser (Chrome, Edge, Firefox). No installation is needed.
  3. The pages load two fonts from Google Fonts; without internet they use a fallback font and still work.

Notes
  - Results are exploratory: 50 held-out test cases per setting, 3 training seeds for most agents.
  - The training demo is a toy world (2 machines, 8 jobs), labelled as a toy on the page.
